execute unless entity @s[nbt={active_effects: [{id: "minecraft:unluck"}]}] run execute anchored eyes run summon wind_charge ^ ^ ^.75 {Tags:["motion_projectile"]}
execute unless entity @s[nbt={active_effects: [{id: "minecraft:unluck"}]}] run execute as @e[tag=motion_projectile] at @s rotated as @s run function main:backend/apply_motion
execute unless entity @s[nbt={active_effects: [{id: "minecraft:unluck"}]}] run effect give @s unluck 1 0 false
