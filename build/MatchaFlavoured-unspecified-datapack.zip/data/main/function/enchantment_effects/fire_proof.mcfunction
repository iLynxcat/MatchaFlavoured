effect give @s minecraft:fire_resistance 1 0 true
