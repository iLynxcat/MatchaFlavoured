tag @s remove ExcludeFromXPRemoval
