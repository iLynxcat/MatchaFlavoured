tag @s add ExcludeFromXPRemoval
xp set @s 50 levels
scoreboard players reset @s anvil_interaction
execute as @s schedule function main:mechanic/clear_xp_tag 15s
